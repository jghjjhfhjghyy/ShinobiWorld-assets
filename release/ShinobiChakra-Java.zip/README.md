# Chakra Nexus — Java pack source

This directory is the source pack for the five Chakra Nexus clan crests and the
first five technique cards. It uses the current data-driven `minecraft:item_model`
format: `assets/shinobi/items/*.json` selects a model, while gameplay is still
validated only through server-owned persistent data.

`technique_great_fireball` is intentionally its own model instead of reusing the
Uchiha crest. Its final transparent texture belongs at
`assets/shinobi/textures/item/technique_great_fireball.png`; the model references
that exact resource location. The card stays a server-owned `FIRE_CHARGE`, but
Java renders it as the Katon technique seal once the pack is loaded.

`pack.mcmeta` is pinned to Java 26.2 resource-pack version 88.0. Zip the
**contents** of this directory (not the directory itself), upload the archive to
a stable HTTPS URL, calculate its SHA-1, and put the URL and hash in
`plugins/ShinobiChakra/config.yml`.

The plugin deliberately does not invent a URL or force an unreachable pack.
Until a real URL is configured, the same menu and controls use safe vanilla
icons rather than blocking players with a broken download prompt.
